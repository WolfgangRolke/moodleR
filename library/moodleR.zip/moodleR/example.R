example1=function() {
   category="Example / 1"
   quizname="problem -"
   n=50+1*sample(0:50, 1)
   m=90+1*sample(0:20, 1)
   s = 10
   x=rnorm(n, m, s)
   x=round(x, 1)
   res=as.list(1:1)
   plt=bplot(x,return.graph=TRUE)
   plt64=png64(plt)
   res[[1]]= mean(x)
   qtxt =  paste0( "<p>The mean is  ",nm(res[[1]], w = 100, eps = 0.1)," </p>" )
   atxt =  paste0( "<p>The mean is  ", res[[1]]," </p>" )
   htxt = "  "
   list(qtxt = paste0("<h5>", qtxt, "</h5>",
       plt64,
       moodle.table(x)),
       htxt = paste0("<h5>", htxt, "</h5>"),
       atxt = paste0("<h5>", atxt, "</h5>"),
       category = category, quizname = quizname)
}
